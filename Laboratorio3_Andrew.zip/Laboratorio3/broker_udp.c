#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define UDP_PORT 5001
#define BUFFER_SIZE 2048
#define MAX_SUBSCRIPTIONS 500
#define MAX_TOPIC_LENGTH 100

typedef struct
{
    struct sockaddr_in address;
    char topic[MAX_TOPIC_LENGTH];
} Subscription;


/*
 * Compara dos direcciones UDP.
 *
 * Para considerar que se trata del mismo cliente,
 * deben coincidir tanto la IP como el puerto.
 */
static int same_address(
    const struct sockaddr_in *a,
    const struct sockaddr_in *b)
{
    return
        a->sin_addr.s_addr == b->sin_addr.s_addr &&
        a->sin_port == b->sin_port;
}


/*
 * Procesa un mensaje UDP recibido.
 *
 * Formatos:
 *
 * SUB|partido
 * PUB|partido|mensaje
 */
static void process_message(
    int broker_socket,
    char *message,
    const struct sockaddr_in *sender_addr,
    Subscription subscriptions[],
    int *subscription_count)
{
    char sender_ip[INET_ADDRSTRLEN];

    inet_ntop(
        AF_INET,
        &sender_addr->sin_addr,
        sender_ip,
        sizeof(sender_ip)
    );

    printf(
        "Datagrama recibido desde %s:%d -> %s\n",
        sender_ip,
        ntohs(sender_addr->sin_port),
        message
    );


    /*
     * ========================================
     * SUSCRIPCION
     * SUB|partido
     * ========================================
     */
    if (strncmp(message, "SUB|", 4) == 0)
    {
        char *topic = message + 4;

        if (
            strlen(topic) == 0 ||
            strchr(topic, '|') != NULL)
        {
            printf(
                "Suscripcion UDP invalida.\n"
            );

            return;
        }

        int already_subscribed = 0;

        for (int i = 0; i < *subscription_count; i++)
        {
            if (
                same_address(
                    &subscriptions[i].address,
                    sender_addr
                ) &&
                strcmp(
                    subscriptions[i].topic,
                    topic
                ) == 0)
            {
                already_subscribed = 1;
                break;
            }
        }

        if (already_subscribed)
        {
            printf(
                "%s:%d ya estaba suscrito a %s.\n",
                sender_ip,
                ntohs(sender_addr->sin_port),
                topic
            );

            return;
        }

        if (*subscription_count >= MAX_SUBSCRIPTIONS)
        {
            printf(
                "No hay espacio para mas suscripciones UDP.\n"
            );

            return;
        }

        subscriptions[*subscription_count].address =
            *sender_addr;

        strncpy(
            subscriptions[*subscription_count].topic,
            topic,
            MAX_TOPIC_LENGTH - 1
        );

        subscriptions[*subscription_count]
            .topic[MAX_TOPIC_LENGTH - 1] = '\0';

        (*subscription_count)++;

        printf(
            "Suscripcion UDP registrada: "
            "%s:%d -> %s\n",
            sender_ip,
            ntohs(sender_addr->sin_port),
            topic
        );

        return;
    }


    /*
     * ========================================
     * PUBLICACION
     * PUB|partido|mensaje
     * ========================================
     */
    if (strncmp(message, "PUB|", 4) == 0)
    {
        char *content = message + 4;

        char *separator =
            strchr(content, '|');

        if (separator == NULL)
        {
            printf(
                "Publicacion UDP invalida.\n"
            );

            return;
        }

        /*
         * Separar:
         *
         * partido|mensaje
         */
        *separator = '\0';

        char *topic = content;
        char *publication = separator + 1;

        if (
            strlen(topic) == 0 ||
            strlen(publication) == 0)
        {
            printf(
                "Publicacion UDP invalida.\n"
            );

            return;
        }

        char outgoing[BUFFER_SIZE];

        int written = snprintf(
            outgoing,
            sizeof(outgoing),
            "MSG|%s|%s",
            topic,
            publication
        );

        if (
            written < 0 ||
            (size_t)written >= sizeof(outgoing))
        {
            printf(
                "La publicacion UDP excede "
                "el tamano maximo permitido.\n"
            );

            return;
        }

        printf(
            "Publicacion UDP recibida: "
            "%s -> %s\n",
            topic,
            publication
        );

        int delivered = 0;

        /*
         * Enviar un datagrama a cada subscriber
         * registrado en ese partido.
         */
        for (int i = 0; i < *subscription_count; i++)
        {
            if (
                strcmp(
                    subscriptions[i].topic,
                    topic
                ) == 0)
            {
                ssize_t sent = sendto(
                    broker_socket,
                    outgoing,
                    strlen(outgoing),
                    0,
                    (struct sockaddr *)
                        &subscriptions[i].address,
                    sizeof(
                        subscriptions[i].address
                    )
                );

                if (sent < 0)
                {
                    perror(
                        "Error enviando datagrama "
                        "al subscriber"
                    );
                }
                else
                {
                    char subscriber_ip[
                        INET_ADDRSTRLEN
                    ];

                    inet_ntop(
                        AF_INET,
                        &subscriptions[i]
                            .address.sin_addr,
                        subscriber_ip,
                        sizeof(subscriber_ip)
                    );

                    printf(
                        "Mensaje UDP reenviado a "
                        "%s:%d.\n",
                        subscriber_ip,
                        ntohs(
                            subscriptions[i]
                                .address.sin_port
                        )
                    );

                    delivered++;
                }
            }
        }

        printf(
            "Publicacion UDP entregada a "
            "%d subscriber(s).\n",
            delivered
        );

        return;
    }


    /*
     * Mensaje fuera del protocolo.
     */
    printf(
        "Tipo de mensaje UDP desconocido.\n"
    );
}


int main(void)
{
    int broker_socket;
    int opt = 1;

    struct sockaddr_in broker_addr;
    struct sockaddr_in sender_addr;

    socklen_t sender_addr_len;

    char buffer[BUFFER_SIZE];

    Subscription subscriptions[
        MAX_SUBSCRIPTIONS
    ];

    int subscription_count = 0;


    /*
     * ========================================
     * CREAR SOCKET UDP
     * ========================================
     */
    broker_socket = socket(
        AF_INET,
        SOCK_DGRAM,
        0
    );

    if (broker_socket < 0)
    {
        perror("Error creando el socket UDP");
        return 1;
    }

    printf(
        "Socket UDP creado correctamente.\n"
    );


    /*
     * Permitir reutilizar el puerto.
     */
    if (
        setsockopt(
            broker_socket,
            SOL_SOCKET,
            SO_REUSEADDR,
            &opt,
            sizeof(opt)
        ) < 0)
    {
        perror(
            "Error configurando el socket UDP"
        );

        close(broker_socket);
        return 1;
    }


    /*
     * ========================================
     * CONFIGURAR DIRECCION DEL BROKER
     * ========================================
     */
    memset(
        &broker_addr,
        0,
        sizeof(broker_addr)
    );

    broker_addr.sin_family = AF_INET;
    broker_addr.sin_addr.s_addr = INADDR_ANY;
    broker_addr.sin_port = htons(UDP_PORT);


    /*
     * Asociar el socket UDP al puerto 5001.
     */
    if (
        bind(
            broker_socket,
            (struct sockaddr *)&broker_addr,
            sizeof(broker_addr)
        ) < 0)
    {
        perror("Error en bind UDP");

        close(broker_socket);
        return 1;
    }

    printf(
        "Broker UDP escuchando en el puerto %d...\n",
        UDP_PORT
    );


    /*
     * ========================================
     * CICLO PRINCIPAL DEL BROKER UDP
     * ========================================
     */
    while (1)
    {
        sender_addr_len =
            sizeof(sender_addr);

        ssize_t bytes_received = recvfrom(
            broker_socket,
            buffer,
            BUFFER_SIZE - 1,
            0,
            (struct sockaddr *)&sender_addr,
            &sender_addr_len
        );

        if (bytes_received < 0)
        {
            perror(
                "Error recibiendo datagrama UDP"
            );

            continue;
        }

        /*
         * Cada recvfrom() devuelve un datagrama
         * independiente, por lo que no necesitamos
         * reconstruir mensajes como en TCP.
         */
        buffer[bytes_received] = '\0';

        /*
         * nc agrega salto de linea al presionar
         * Enter. Lo quitamos para procesar
         * solamente el mensaje del protocolo.
         */
        buffer[
            strcspn(buffer, "\r\n")
        ] = '\0';

        if (strlen(buffer) == 0)
        {
            continue;
        }

        process_message(
            broker_socket,
            buffer,
            &sender_addr,
            subscriptions,
            &subscription_count
        );
    }


    close(broker_socket);

    return 0;
}
