PROYECTO DEPORTIVO PUB/SUB — ARCHIVOS FUENTE

Contenido
---------
broker_tcp.c      Broker TCP, puerto 5000
broker_udp.c      Broker UDP, puerto 5001
publisher_tcp.c   Publicador TCP: envía 10 eventos de ejemplo
publisher_udp.c   Publicador UDP: envía 10 eventos de ejemplo

Compilar en Ubuntu
------------------
gcc -Wall -Wextra broker_tcp.c -o broker_tcp
gcc -Wall -Wextra broker_udp.c -o broker_udp
gcc -Wall -Wextra publisher_tcp.c -o publisher_tcp
gcc -Wall -Wextra publisher_udp.c -o publisher_udp

Prueba rápida de publicadores
-----------------------------
Terminal 1:
  ./broker_tcp

Terminal 2:
  ./publisher_tcp
Escribir el mismo tema que usarán los suscriptores, por ejemplo:
  partido_1

Para UDP, detener el broker TCP y ejecutar:

Terminal 1:
  ./broker_udp

Terminal 2:
  ./publisher_udp
Escribir:
  partido_1

Para probar entrega de extremo a extremo, primero hay que ejecutar los
suscriptores y suscribirlos al mismo tema antes de iniciar el publicador.
Los publicadores por sí solos solo comprueban el envío al broker; no prueban
que los suscriptores reciban los mensajes.

Si el broker está en otra máquina, pasar su IP como argumento:
  ./publisher_tcp 192.168.1.20
  ./publisher_udp 192.168.1.20

Notas
-----
- Los publicadores envían 10 eventos con una pausa de 1 segundo.
- TCP usa mensajes terminados en salto de línea; UDP usa un datagrama por evento.
- Los fuentes de esta carpeta son una versión empaquetada para compartir.
  Antes de la integración final, el grupo debe confirmar que todos usa la misma
  versión de los brokers y suscriptores, y que los comandos/protocolos coinciden.
- No se incluyen ejecutables compilados: cada compañero los compila en su equipo.
