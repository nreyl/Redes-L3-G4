#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define UDP_PORT 5001
#define BUFFER_SIZE 2048
#define MAX_SUBSCRIBERS 100
#define TOPIC_SIZE 128

typedef struct {
    struct sockaddr_in address;
    char topic[TOPIC_SIZE];
    int active;
} Subscriber;

static Subscriber subscribers[MAX_SUBSCRIBERS];

static int same_address(const struct sockaddr_in *a,
                        const struct sockaddr_in *b) {
    return a->sin_addr.s_addr == b->sin_addr.s_addr &&
           a->sin_port == b->sin_port;
}

int main(void) {
    int sockfd = socket(AF_INET, SOCK_DGRAM, 0);
    if (sockfd < 0) { perror("socket"); return 1; }

    struct sockaddr_in server_address;
    memset(&server_address, 0, sizeof(server_address));
    server_address.sin_family = AF_INET;
    server_address.sin_addr.s_addr = htonl(INADDR_ANY);
    server_address.sin_port = htons(UDP_PORT);

    if (bind(sockfd, (struct sockaddr *)&server_address,
             sizeof(server_address)) < 0) {
        perror("bind"); close(sockfd); return 1;
    }

    memset(subscribers, 0, sizeof(subscribers));
    printf("Broker UDP escuchando en el puerto %d\n", UDP_PORT);

    while (1) {
        char buffer[BUFFER_SIZE];
        struct sockaddr_in sender;
        socklen_t sender_len = sizeof(sender);
        ssize_t n = recvfrom(sockfd, buffer, sizeof(buffer) - 1, 0,
                             (struct sockaddr *)&sender, &sender_len);
        if (n < 0) { perror("recvfrom"); continue; }
        buffer[n] = '\0';

        if (strncmp(buffer, "SUB|", 4) == 0) {
            char *topic = buffer + 4;
            if (*topic == '\0' || strchr(topic, '|') != NULL) continue;

            int slot = -1;
            for (int i = 0; i < MAX_SUBSCRIBERS; i++) {
                if (subscribers[i].active &&
                    same_address(&subscribers[i].address, &sender) &&
                    strcmp(subscribers[i].topic, topic) == 0) {
                    slot = i; break;
                }
                if (!subscribers[i].active && slot < 0) slot = i;
            }
            if (slot >= 0) {
                subscribers[slot].address = sender;
                snprintf(subscribers[slot].topic, TOPIC_SIZE, "%s", topic);
                subscribers[slot].active = 1;
                printf("Suscriptor UDP %s:%d registrado en tema %s\n",
                       inet_ntoa(sender.sin_addr), ntohs(sender.sin_port), topic);
            }
            continue;
        }

        if (strncmp(buffer, "PUB|", 4) == 0) {
            char *topic = buffer + 4;
            char *separator = strchr(topic, '|');
            if (separator == NULL) continue;
            *separator = '\0';
            char *message = separator + 1;

            char outgoing[BUFFER_SIZE];
            int out_len = snprintf(outgoing, sizeof(outgoing),
                                   "MSG|%s|%s", topic, message);
            if (out_len < 0 || (size_t)out_len >= sizeof(outgoing)) continue;

            int delivered = 0;
            for (int i = 0; i < MAX_SUBSCRIBERS; i++) {
                if (subscribers[i].active &&
                    strcmp(subscribers[i].topic, topic) == 0) {
                    ssize_t sent = sendto(sockfd, outgoing, (size_t)out_len, 0,
                        (struct sockaddr *)&subscribers[i].address,
                        sizeof(subscribers[i].address));
                    if (sent >= 0) delivered++;
                }
            }
            printf("Publicacion UDP en tema %s entregada a %d subscriber(s)\n",
                   topic, delivered);
        }
    }

    close(sockfd);
    return 0;
}
