#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define TCP_PORT 5000
#define BUFFER_SIZE 2048
#define MAX_CLIENTS 100
#define MAX_SUBSCRIPTIONS 500
#define MAX_TOPIC_LENGTH 100

typedef struct
{
    int socket;
    char topic[MAX_TOPIC_LENGTH];
} Subscription;


/*
 * Elimina todas las suscripciones asociadas
 * a un socket que se haya desconectado.
 */
static void remove_subscriptions_for_socket(
    Subscription subscriptions[],
    int *subscription_count,
    int socket_fd)
{
    int i = 0;

    while (i < *subscription_count)
    {
        if (subscriptions[i].socket == socket_fd)
        {
            for (int j = i; j < *subscription_count - 1; j++)
            {
                subscriptions[j] = subscriptions[j + 1];
            }

            (*subscription_count)--;
        }
        else
        {
            i++;
        }
    }
}


/*
 * send() no garantiza enviar todos los bytes
 * en una sola llamada.
 *
 * Esta funcion sigue enviando hasta completar
 * el mensaje.
 */
static int send_all(
    int socket_fd,
    const char *data,
    size_t length)
{
    size_t total_sent = 0;

    while (total_sent < length)
    {
        ssize_t sent = send(
            socket_fd,
            data + total_sent,
            length - total_sent,
            MSG_NOSIGNAL
        );

        if (sent < 0)
        {
            if (errno == EINTR)
            {
                continue;
            }

            return -1;
        }

        if (sent == 0)
        {
            return -1;
        }

        total_sent += (size_t)sent;
    }

    return 0;
}


/*
 * Procesa un mensaje TCP completo.
 *
 * Formatos aceptados:
 *
 * SUB|partido
 * PUB|partido|mensaje
 */
static void process_message(
    int socket_fd,
    char *message,
    Subscription subscriptions[],
    int *subscription_count)
{
    printf(
        "Socket %d envio: %s\n",
        socket_fd,
        message
    );

    /*
     * ----------------------------------------
     * SUSCRIPCION
     * SUB|partido
     * ----------------------------------------
     */
    if (strncmp(message, "SUB|", 4) == 0)
    {
        char *topic = message + 4;

        /*
         * El nombre del partido no puede ser
         * vacio ni contener el separador '|'.
         */
        if (strlen(topic) == 0 || strchr(topic, '|') != NULL)
        {
            printf(
                "Suscripcion invalida recibida del socket %d.\n",
                socket_fd
            );

            return;
        }

        int already_subscribed = 0;

        for (int i = 0; i < *subscription_count; i++)
        {
            if (
                subscriptions[i].socket == socket_fd &&
                strcmp(subscriptions[i].topic, topic) == 0)
            {
                already_subscribed = 1;
                break;
            }
        }

        if (already_subscribed)
        {
            printf(
                "Socket %d ya estaba suscrito a %s.\n",
                socket_fd,
                topic
            );

            return;
        }

        if (*subscription_count >= MAX_SUBSCRIPTIONS)
        {
            printf(
                "No hay espacio para mas suscripciones.\n"
            );

            return;
        }

        subscriptions[*subscription_count].socket = socket_fd;

        strncpy(
            subscriptions[*subscription_count].topic,
            topic,
            MAX_TOPIC_LENGTH - 1
        );

        subscriptions[*subscription_count]
            .topic[MAX_TOPIC_LENGTH - 1] = '\0';

        (*subscription_count)++;

        printf(
            "Suscripcion registrada: socket %d -> %s\n",
            socket_fd,
            topic
        );

        return;
    }


    /*
     * ----------------------------------------
     * PUBLICACION
     * PUB|partido|mensaje
     * ----------------------------------------
     */
    if (strncmp(message, "PUB|", 4) == 0)
    {
        char *content = message + 4;

        /*
         * Buscar el separador entre:
         *
         * partido|mensaje
         */
        char *separator = strchr(content, '|');

        if (separator == NULL)
        {
            printf(
                "Publicacion invalida recibida del socket %d.\n",
                socket_fd
            );

            return;
        }

        /*
         * Reemplazamos temporalmente el '|'
         * por '\0' para separar las cadenas.
         */
        *separator = '\0';

        char *topic = content;
        char *publication = separator + 1;

        if (
            strlen(topic) == 0 ||
            strlen(publication) == 0)
        {
            printf(
                "Publicacion invalida recibida del socket %d.\n",
                socket_fd
            );

            return;
        }

        char outgoing[BUFFER_SIZE];

        int written = snprintf(
            outgoing,
            sizeof(outgoing),
            "MSG|%s|%s\n",
            topic,
            publication
        );

        if (
            written < 0 ||
            (size_t)written >= sizeof(outgoing))
        {
            printf(
                "La publicacion excede el tamano maximo permitido.\n"
            );

            return;
        }

        printf(
            "Publicacion recibida: %s -> %s\n",
            topic,
            publication
        );

        int delivered = 0;

        /*
         * Enviar la publicacion solamente a
         * los subscribers registrados para
         * este partido.
         */
        for (int i = 0; i < *subscription_count; i++)
        {
            if (
                strcmp(
                    subscriptions[i].topic,
                    topic
                ) == 0)
            {
                int subscriber_socket =
                    subscriptions[i].socket;

                if (
                    send_all(
                        subscriber_socket,
                        outgoing,
                        strlen(outgoing)
                    ) < 0)
                {
                    perror(
                        "Error enviando mensaje al subscriber"
                    );
                }
                else
                {
                    delivered++;

                    printf(
                        "Mensaje reenviado al socket %d.\n",
                        subscriber_socket
                    );
                }
            }
        }

        printf(
            "Publicacion entregada a %d subscriber(s).\n",
            delivered
        );

        return;
    }


    /*
     * Cualquier otro tipo de mensaje
     * no pertenece al protocolo.
     */
    printf(
        "Tipo de mensaje desconocido recibido del socket %d.\n",
        socket_fd
    );
}


int main(void)
{
    int server_socket;
    int client_socket;

    int client_sockets[MAX_CLIENTS];

    /*
     * Cada cliente TCP tiene su propio buffer
     * acumulado.
     *
     * Esto permite manejar:
     *
     * - mensajes fragmentados entre varios recv()
     * - varios mensajes recibidos en un solo recv()
     */
    char client_buffers[MAX_CLIENTS][BUFFER_SIZE * 2];
    size_t client_buffer_lengths[MAX_CLIENTS];

    Subscription subscriptions[MAX_SUBSCRIPTIONS];
    int subscription_count = 0;

    int opt = 1;
    int max_sd;
    int activity;
    int sd;

    struct sockaddr_in server_addr;
    struct sockaddr_in client_addr;

    socklen_t client_addr_len;

    char received_data[BUFFER_SIZE];

    fd_set readfds;


    /*
     * Inicializar estructuras de clientes.
     */
    for (int i = 0; i < MAX_CLIENTS; i++)
    {
        client_sockets[i] = 0;
        client_buffer_lengths[i] = 0;
        client_buffers[i][0] = '\0';
    }


    /*
     * Crear socket TCP.
     */
    server_socket = socket(
        AF_INET,
        SOCK_STREAM,
        0
    );

    if (server_socket < 0)
    {
        perror("Error creando el socket");
        return 1;
    }

    printf("Socket TCP creado correctamente.\n");


    /*
     * Permitir reutilizar rapidamente el puerto.
     */
    if (
        setsockopt(
            server_socket,
            SOL_SOCKET,
            SO_REUSEADDR,
            &opt,
            sizeof(opt)
        ) < 0)
    {
        perror("Error configurando el socket");
        close(server_socket);
        return 1;
    }


    /*
     * Configurar direccion del broker.
     */
    memset(
        &server_addr,
        0,
        sizeof(server_addr)
    );

    server_addr.sin_family = AF_INET;
    server_addr.sin_addr.s_addr = INADDR_ANY;
    server_addr.sin_port = htons(TCP_PORT);


    /*
     * Asociar socket al puerto 5000.
     */
    if (
        bind(
            server_socket,
            (struct sockaddr *)&server_addr,
            sizeof(server_addr)
        ) < 0)
    {
        perror("Error en bind");
        close(server_socket);
        return 1;
    }

    printf(
        "Socket asociado correctamente al puerto %d.\n",
        TCP_PORT
    );


    /*
     * Poner el socket en modo escucha.
     */
    if (
        listen(
            server_socket,
            MAX_CLIENTS
        ) < 0)
    {
        perror("Error en listen");
        close(server_socket);
        return 1;
    }

    printf(
        "Broker TCP escuchando en el puerto %d...\n",
        TCP_PORT
    );


    /*
     * ========================================
     * CICLO PRINCIPAL DEL BROKER
     * ========================================
     */
    while (1)
    {
        FD_ZERO(&readfds);

        /*
         * Vigilar nuevas conexiones.
         */
        FD_SET(
            server_socket,
            &readfds
        );

        max_sd = server_socket;


        /*
         * Agregar todos los clientes conectados
         * al conjunto vigilado por select().
         */
        for (int i = 0; i < MAX_CLIENTS; i++)
        {
            sd = client_sockets[i];

            if (sd > 0)
            {
                FD_SET(
                    sd,
                    &readfds
                );
            }

            if (sd > max_sd)
            {
                max_sd = sd;
            }
        }


        /*
         * Esperar hasta que exista actividad
         * en algun socket.
         */
        activity = select(
            max_sd + 1,
            &readfds,
            NULL,
            NULL,
            NULL
        );

        if (activity < 0)
        {
            if (errno == EINTR)
            {
                continue;
            }

            perror("Error en select");
            break;
        }


        /*
         * ====================================
         * NUEVA CONEXION
         * ====================================
         */
        if (
            FD_ISSET(
                server_socket,
                &readfds
            ))
        {
            client_addr_len =
                sizeof(client_addr);

            client_socket = accept(
                server_socket,
                (struct sockaddr *)&client_addr,
                &client_addr_len
            );

            if (client_socket < 0)
            {
                perror("Error en accept");
            }
            else
            {
                printf(
                    "Nuevo cliente conectado desde "
                    "%s:%d - socket %d\n",
                    inet_ntoa(client_addr.sin_addr),
                    ntohs(client_addr.sin_port),
                    client_socket
                );

                int client_stored = 0;

                for (int i = 0; i < MAX_CLIENTS; i++)
                {
                    if (client_sockets[i] == 0)
                    {
                        client_sockets[i] =
                            client_socket;

                        client_buffer_lengths[i] = 0;
                        client_buffers[i][0] = '\0';

                        client_stored = 1;
                        break;
                    }
                }

                if (!client_stored)
                {
                    printf(
                        "No hay espacio para mas clientes. "
                        "Conexion rechazada.\n"
                    );

                    close(client_socket);
                }
            }
        }


        /*
         * ====================================
         * DATOS DE CLIENTES EXISTENTES
         * ====================================
         */
        for (int i = 0; i < MAX_CLIENTS; i++)
        {
            sd = client_sockets[i];

            if (
                sd <= 0 ||
                !FD_ISSET(sd, &readfds))
            {
                continue;
            }

            ssize_t bytes_received = recv(
                sd,
                received_data,
                sizeof(received_data),
                0
            );


            /*
             * --------------------------------
             * CLIENTE DESCONECTADO
             * --------------------------------
             */
            if (bytes_received == 0)
            {
                printf(
                    "Cliente desconectado - socket %d\n",
                    sd
                );

                remove_subscriptions_for_socket(
                    subscriptions,
                    &subscription_count,
                    sd
                );

                close(sd);

                client_sockets[i] = 0;
                client_buffer_lengths[i] = 0;
                client_buffers[i][0] = '\0';

                continue;
            }


            /*
             * Error en recv().
             */
            if (bytes_received < 0)
            {
                if (errno == EINTR)
                {
                    continue;
                }

                perror("Error recibiendo datos");

                remove_subscriptions_for_socket(
                    subscriptions,
                    &subscription_count,
                    sd
                );

                close(sd);

                client_sockets[i] = 0;
                client_buffer_lengths[i] = 0;
                client_buffers[i][0] = '\0';

                continue;
            }


            /*
             * --------------------------------
             * ACUMULAR BYTES RECIBIDOS
             * --------------------------------
             */
            size_t current_length =
                client_buffer_lengths[i];

            size_t incoming_length =
                (size_t)bytes_received;

            size_t capacity =
                sizeof(client_buffers[i]);

            if (
                current_length +
                incoming_length >= capacity)
            {
                printf(
                    "Buffer TCP excedido en socket %d. "
                    "Conexion cerrada.\n",
                    sd
                );

                remove_subscriptions_for_socket(
                    subscriptions,
                    &subscription_count,
                    sd
                );

                close(sd);

                client_sockets[i] = 0;
                client_buffer_lengths[i] = 0;
                client_buffers[i][0] = '\0';

                continue;
            }

            memcpy(
                client_buffers[i] + current_length,
                received_data,
                incoming_length
            );

            client_buffer_lengths[i] +=
                incoming_length;

            client_buffers[i][
                client_buffer_lengths[i]
            ] = '\0';


            /*
             * --------------------------------
             * EXTRAER MENSAJES COMPLETOS
             * --------------------------------
             *
             * Un mensaje termina cuando aparece:
             *
             * \n
             */
            while (1)
            {
                char *newline = memchr(
                    client_buffers[i],
                    '\n',
                    client_buffer_lengths[i]
                );

                /*
                 * Todavia no hay un mensaje
                 * completo.
                 */
                if (newline == NULL)
                {
                    break;
                }

                size_t raw_line_length =
                    (size_t)(
                        newline -
                        client_buffers[i]
                    );

                size_t message_length =
                    raw_line_length;

                /*
                 * Soportar tambien terminaciones
                 * de linea tipo \r\n.
                 */
                if (
                    message_length > 0 &&
                    client_buffers[i][
                        message_length - 1
                    ] == '\r')
                {
                    message_length--;
                }


                /*
                 * Procesar la linea si no esta vacia.
                 */
                if (message_length > 0)
                {
                    if (
                        message_length >=
                        BUFFER_SIZE)
                    {
                        printf(
                            "Mensaje demasiado largo "
                            "recibido del socket %d.\n",
                            sd
                        );
                    }
                    else
                    {
                        char complete_message[
                            BUFFER_SIZE
                        ];

                        memcpy(
                            complete_message,
                            client_buffers[i],
                            message_length
                        );

                        complete_message[
                            message_length
                        ] = '\0';

                        process_message(
                            sd,
                            complete_message,
                            subscriptions,
                            &subscription_count
                        );
                    }
                }


                /*
                 * Eliminar del buffer el mensaje
                 * que ya fue procesado.
                 */
                size_t consumed =
                    raw_line_length + 1;

                size_t remaining =
                    client_buffer_lengths[i] -
                    consumed;

                memmove(
                    client_buffers[i],
                    client_buffers[i] + consumed,
                    remaining
                );

                client_buffer_lengths[i] =
                    remaining;

                client_buffers[i][remaining] =
                    '\0';
            }


            /*
             * Si tenemos 2048 bytes sin encontrar
             * '\n', el cliente esta enviando un
             * mensaje superior al limite acordado.
             */
            if (
                client_buffer_lengths[i] >=
                BUFFER_SIZE)
            {
                printf(
                    "Mensaje TCP demasiado largo o "
                    "sin terminador de linea en "
                    "socket %d. Conexion cerrada.\n",
                    sd
                );

                remove_subscriptions_for_socket(
                    subscriptions,
                    &subscription_count,
                    sd
                );

                close(sd);

                client_sockets[i] = 0;
                client_buffer_lengths[i] = 0;
                client_buffers[i][0] = '\0';
            }
        }
    }


    /*
     * Cerrar conexiones antes de terminar.
     */
    for (int i = 0; i < MAX_CLIENTS; i++)
    {
        if (client_sockets[i] > 0)
        {
            close(client_sockets[i]);
        }
    }

    close(server_socket);

    return 0;
}
