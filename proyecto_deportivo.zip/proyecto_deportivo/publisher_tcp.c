#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define TCP_PORT 5000
#define BUFFER_SIZE 2048
#define TOPIC_SIZE 128

static int send_all(int fd, const char *data, size_t length) {
    size_t sent = 0;
    while (sent < length) {
        ssize_t n = send(fd, data + sent, length - sent, 0);
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) return -1;
        sent += (size_t)n;
    }
    return 0;
}

int main(int argc, char *argv[]) {
    int sockfd;
    struct sockaddr_in broker_address;
    const char *broker_ip = (argc == 2) ? argv[1] : "127.0.0.1";
    char topic[TOPIC_SIZE];
    char packet[BUFFER_SIZE];

    const char *events[] = {
        "Inicio del partido: Colombia vs Argentina",
        "Minuto 8: remate de Colombia atajado",
        "Minuto 17: tarjeta amarilla para Argentina",
        "Minuto 32: gol de Colombia, marcador 1-0",
        "Minuto 45: termina el primer tiempo",
        "Minuto 52: cambio de jugador en Argentina",
        "Minuto 63: tarjeta amarilla para Colombia",
        "Minuto 71: gol de Argentina, marcador 1-1",
        "Minuto 84: cambio de jugador en Colombia",
        "Minuto 90: final del partido, marcador 1-1"
    };
    const size_t event_count = sizeof(events) / sizeof(events[0]);

    if (argc > 2) {
        fprintf(stderr, "Uso: %s [IP_DEL_BROKER]\n", argv[0]);
        return 1;
    }

    printf("Publicador TCP\nBroker: %s:%d\n", broker_ip, TCP_PORT);
    printf("Escribe el tema del partido (ejemplo: partido_1): ");
    if (fgets(topic, sizeof(topic), stdin) == NULL) {
        fprintf(stderr, "No se pudo leer el tema.\n");
        return 1;
    }
    topic[strcspn(topic, "\r\n")] = '\0';
    if (topic[0] == '\0') strcpy(topic, "partido_1");
    if (strchr(topic, '|') != NULL) {
        fprintf(stderr, "El tema no puede contener el caracter '|'.\n");
        return 1;
    }

    sockfd = socket(AF_INET, SOCK_STREAM, 0);
    if (sockfd < 0) {
        perror("socket");
        return 1;
    }

    memset(&broker_address, 0, sizeof(broker_address));
    broker_address.sin_family = AF_INET;
    broker_address.sin_port = htons(TCP_PORT);
    if (inet_pton(AF_INET, broker_ip, &broker_address.sin_addr) != 1) {
        fprintf(stderr, "Direccion IP invalida: %s\n", broker_ip);
        close(sockfd);
        return 1;
    }
    if (connect(sockfd, (struct sockaddr *)&broker_address,
                sizeof(broker_address)) < 0) {
        perror("connect");
        close(sockfd);
        return 1;
    }

    for (size_t i = 0; i < event_count; i++) {
        int length = snprintf(packet, sizeof(packet), "PUB|%s|%s\n",
                              topic, events[i]);
        if (length < 0 || (size_t)length >= sizeof(packet)) {
            fprintf(stderr, "Mensaje demasiado largo.\n");
            close(sockfd);
            return 1;
        }
        if (send_all(sockfd, packet, (size_t)length) < 0) {
            perror("send");
            close(sockfd);
            return 1;
        }
        printf("Evento %zu/%zu enviado: %s\n", i + 1, event_count, events[i]);
        sleep(1);
    }

    close(sockfd);
    printf("Publicador TCP finalizado.\n");
    return 0;
}
