#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <errno.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/select.h>
#include <netinet/in.h>
#include <arpa/inet.h>

#define TCP_PORT 5000
#define BUFFER_SIZE 2048
#define MAX_CLIENTS 100
#define MAX_TOPICS 100
#define TOPIC_SIZE 128

typedef struct {
    int fd;
    char input[BUFFER_SIZE];
    size_t used;
    char topics[MAX_TOPICS][TOPIC_SIZE];
    int topic_count;
} Client;

static Client clients[MAX_CLIENTS];

static int send_all(int fd, const char *data, size_t length) {
    size_t sent = 0;
    while (sent < length) {
        ssize_t n = send(fd, data + sent, length - sent, 0);
        if (n < 0 && errno == EINTR) continue;
        if (n <= 0) return -1;
        sent += (size_t)n;
    }
    return 0;
}

static int has_topic(const Client *client, const char *topic) {
    for (int i = 0; i < client->topic_count; i++)
        if (strcmp(client->topics[i], topic) == 0) return 1;
    return 0;
}

static void process_line(int sender, char *line) {
    char *save = NULL;
    char *command = strtok_r(line, "|", &save);
    if (command == NULL) return;

    if (strcmp(command, "SUB") == 0) {
        char *topic = strtok_r(NULL, "|", &save);
        if (topic == NULL || topic[0] == '\0') return;
        if (clients[sender].topic_count < MAX_TOPICS &&
            !has_topic(&clients[sender], topic)) {
            snprintf(clients[sender].topics[clients[sender].topic_count],
                     TOPIC_SIZE, "%s", topic);
            clients[sender].topic_count++;
            printf("Cliente %d suscrito al tema %s\n",
                   clients[sender].fd, topic);
        }
        return;
    }

    if (strcmp(command, "PUB") == 0) {
        char *topic = strtok_r(NULL, "|", &save);
        char *message = save;
        if (topic == NULL || message == NULL) return;

        char outgoing[BUFFER_SIZE];
        int n = snprintf(outgoing, sizeof(outgoing), "MSG|%s|%s\n", topic, message);
        if (n < 0 || (size_t)n >= sizeof(outgoing)) return;

        int delivered = 0;
        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (clients[i].fd >= 0 && i != sender &&
                has_topic(&clients[i], topic)) {
                if (send_all(clients[i].fd, outgoing, (size_t)n) == 0)
                    delivered++;
            }
        }
        printf("Publicacion TCP en tema %s entregada a %d subscriber(s)\n",
               topic, delivered);
    }
}

int main(void) {
    int server_fd = socket(AF_INET, SOCK_STREAM, 0);
    if (server_fd < 0) { perror("socket"); return 1; }

    int opt = 1;
    (void)setsockopt(server_fd, SOL_SOCKET, SO_REUSEADDR, &opt, sizeof(opt));

    struct sockaddr_in address;
    memset(&address, 0, sizeof(address));
    address.sin_family = AF_INET;
    address.sin_addr.s_addr = htonl(INADDR_ANY);
    address.sin_port = htons(TCP_PORT);

    if (bind(server_fd, (struct sockaddr *)&address, sizeof(address)) < 0) {
        perror("bind"); close(server_fd); return 1;
    }
    if (listen(server_fd, MAX_CLIENTS) < 0) {
        perror("listen"); close(server_fd); return 1;
    }

    for (int i = 0; i < MAX_CLIENTS; i++) clients[i].fd = -1;
    printf("Broker TCP escuchando en el puerto %d\n", TCP_PORT);

    while (1) {
        fd_set readfds;
        FD_ZERO(&readfds);
        FD_SET(server_fd, &readfds);
        int maxfd = server_fd;
        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (clients[i].fd >= 0) {
                FD_SET(clients[i].fd, &readfds);
                if (clients[i].fd > maxfd) maxfd = clients[i].fd;
            }
        }

        int ready = select(maxfd + 1, &readfds, NULL, NULL, NULL);
        if (ready < 0) {
            if (errno == EINTR) continue;
            perror("select"); break;
        }

        if (FD_ISSET(server_fd, &readfds)) {
            int client_fd = accept(server_fd, NULL, NULL);
            if (client_fd >= 0) {
                int slot = -1;
                for (int i = 0; i < MAX_CLIENTS; i++)
                    if (clients[i].fd < 0) { slot = i; break; }
                if (slot >= 0) {
                    clients[slot].fd = client_fd;
                    clients[slot].used = 0;
                    clients[slot].topic_count = 0;
                    printf("Cliente TCP conectado: fd=%d\n", client_fd);
                } else {
                    close(client_fd);
                }
            }
        }

        for (int i = 0; i < MAX_CLIENTS; i++) {
            if (clients[i].fd < 0 || !FD_ISSET(clients[i].fd, &readfds)) continue;
            char temp[BUFFER_SIZE];
            ssize_t n = recv(clients[i].fd, temp, sizeof(temp), 0);
            if (n <= 0) {
                printf("Cliente TCP desconectado: fd=%d\n", clients[i].fd);
                close(clients[i].fd);
                clients[i].fd = -1;
                continue;
            }
            for (ssize_t j = 0; j < n; j++) {
                if (clients[i].used + 1 >= sizeof(clients[i].input)) {
                    clients[i].used = 0;
                }
                if (temp[j] == '\n') {
                    clients[i].input[clients[i].used] = '\0';
                    process_line(i, clients[i].input);
                    clients[i].used = 0;
                } else if (temp[j] != '\r') {
                    clients[i].input[clients[i].used++] = temp[j];
                }
            }
        }
    }

    close(server_fd);
    return 0;
}
