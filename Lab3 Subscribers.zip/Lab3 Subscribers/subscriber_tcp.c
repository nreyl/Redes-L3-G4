#include <stdio.h>
#include <string.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define TCP_PORT 5000
#define BUFFER_SIZE 2048
#define MAX_MATCH_LENGTH 99

int main(int argc, char *argv[]) {
    int subscriberSocket;
    struct sockaddr_in brokerAddress;
    char selectedMatch[MAX_MATCH_LENGTH + 1];
    char subscriptionMessage[BUFFER_SIZE];
    char receivedMessage[BUFFER_SIZE];
    char completeMessage[BUFFER_SIZE];
    const char *brokerIp = (argc == 2) ? argv[1] : "127.0.0.1";
    int subscriptionCount = 0;
    size_t messagePosition = 0;
    int exitStatus = 0;

    if (argc > 2) {
        fprintf(stderr, "Uso: %s [IP_del_broker]\n", argv[0]);
        return 1;
    }

    // 1. Crear el socket TCP
    subscriberSocket = socket(AF_INET, SOCK_STREAM, 0);
    if (subscriberSocket < 0) {
        perror("Error al crear el socket");
        return 1;
    }
    printf("Socket creado correctamente.\n");

    // 2. Configurar la direccion del broker
    memset(&brokerAddress, 0, sizeof(brokerAddress));
    brokerAddress.sin_family = AF_INET;
    brokerAddress.sin_port = htons(TCP_PORT);

    if (inet_pton(AF_INET, brokerIp, &brokerAddress.sin_addr) != 1) {
        fprintf(stderr, "Direccion IPv4 invalida: %s\n", brokerIp);
        close(subscriberSocket);
        return 1;
    }

    // 3. Conectar el subscriber con el broker
    if (connect(subscriberSocket, (struct sockaddr *)&brokerAddress,
                sizeof(brokerAddress)) < 0) {
        perror("Error al conectar el subscriber con el broker");
        close(subscriberSocket);
        return 1;
    }
    printf("Conexion establecida correctamente.\n");

    // 4. Registrar suscripciones: una linea vacia inicia la recepcion
    while (1) {
        printf("Ingrese un partido (linea vacia + Enter para terminar): ");
        fflush(stdout);

        if (fgets(selectedMatch, sizeof(selectedMatch), stdin) == NULL) {
            if (ferror(stdin)) {
                perror("Error al leer el partido");
                exitStatus = 1;
            }
            break;
        }

        // Si no cabe el salto de linea, comprobar si hay caracteres sobrantes.
        size_t matchLength = strcspn(selectedMatch, "\n");
        if (selectedMatch[matchLength] == '\n') {
            selectedMatch[matchLength] = '\0';
        } else {
            int nextCharacter = getchar();
            if (nextCharacter != '\n' && nextCharacter != EOF) {
                while ((nextCharacter = getchar()) != '\n' && nextCharacter != EOF) {
                    // Descartar el resto de la linea demasiado larga.
                }
                printf("Nombre de partido demasiado largo (maximo %d caracteres).\n",
                       MAX_MATCH_LENGTH);
                continue;
            }
        }

        if (selectedMatch[0] == '\0') {
            if (subscriptionCount == 0) {
                printf("Debe suscribirse al menos a un partido.\n");
                continue;
            }
            break;
        }

        if (strchr(selectedMatch, '|') != NULL) {
            printf("El nombre del partido no puede contener '|'.\n");
            continue;
        }

        // El broker interpreta cada suscripcion como SUB|partido\n.
        int messageLength = snprintf(subscriptionMessage, sizeof(subscriptionMessage),
                                     "SUB|%s\n", selectedMatch);
        if (messageLength < 0 || (size_t)messageLength >= sizeof(subscriptionMessage)) {
            fprintf(stderr, "No se pudo construir la suscripcion.\n");
            exitStatus = 1;
            break;
        }

        // TCP puede enviar menos bytes de los solicitados: completar el envio.
        size_t totalBytesSent = 0;
        while (totalBytesSent < (size_t)messageLength) {
            ssize_t bytesSent = send(subscriberSocket,
                                     subscriptionMessage + totalBytesSent,
                                     (size_t)messageLength - totalBytesSent,
                                     MSG_NOSIGNAL);
            if (bytesSent <= 0) {
                if (bytesSent < 0) {
                    perror("Error al enviar la suscripcion");
                } else {
                    fprintf(stderr, "No se pudo completar el envio.\n");
                }
                close(subscriberSocket);
                return 1;
            }
            totalBytesSent += (size_t)bytesSent;
        }

        subscriptionCount++;
        printf("Suscripcion enviada: %s\n", selectedMatch);
    }

    if (exitStatus != 0 || subscriptionCount == 0) {
        if (subscriptionCount == 0 && exitStatus == 0) {
            fprintf(stderr, "No se registraron suscripciones.\n");
            exitStatus = 1;
        }
        close(subscriberSocket);
        return exitStatus;
    }

    printf("Esperando publicaciones del broker...\n");

    // 5. Recibir y reconstruir mensajes terminados en '\n'
    while (1) {
        ssize_t bytesReceived = recv(subscriberSocket, receivedMessage,
                                     sizeof(receivedMessage), 0);
        if (bytesReceived < 0) {
            perror("Error al recibir mensaje del broker");
            exitStatus = 1;
            break;
        }
        if (bytesReceived == 0) {
            printf("El broker cerro la conexion.\n");
            break;
        }

        for (ssize_t i = 0; i < bytesReceived; i++) {
            if (receivedMessage[i] == '\n') {
                completeMessage[messagePosition] = '\0';

                // 6. Interpretar el protocolo MSG|partido|noticia
                if (strncmp(completeMessage, "MSG|", 4) != 0) {
                    printf("Mensaje recibido con formato invalido.\n");
                } else {
                    char *matchName = completeMessage + 4;
                    char *messageSeparator = strchr(matchName, '|');
                    if (messageSeparator == NULL || messageSeparator == matchName ||
                        messageSeparator[1] == '\0' ||
                        strchr(messageSeparator + 1, '|') != NULL) {
                        printf("Mensaje recibido con formato invalido.\n");
                    } else {
                        *messageSeparator = '\0';
                        char *newsContent = messageSeparator + 1;
                        printf("\nPartido: %s\n", matchName);
                        printf("Noticia: %s\n", newsContent);
                    }
                }
                messagePosition = 0;
            } else {
                if (messagePosition >= sizeof(completeMessage) - 1) {
                    fprintf(stderr, "Error: mensaje recibido demasiado largo.\n");
                    close(subscriberSocket);
                    return 1;
                }
                completeMessage[messagePosition++] = receivedMessage[i];
            }
        }
    }

    // 7. Cerrar el socket
    close(subscriberSocket);
    return exitStatus;
}
