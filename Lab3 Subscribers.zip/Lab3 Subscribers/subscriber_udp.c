#include <stdio.h>
#include <string.h>
#include <errno.h>
#include <unistd.h>
#include <arpa/inet.h>
#include <sys/socket.h>

#define UDP_PORT 5001
#define BUFFER_SIZE 2048
#define MAX_TOPIC_LENGTH 100

int main(void) {
    int subscriberSocket;
    struct sockaddr_in brokerAddress;
    char selectedMatch[256];
    char subscriptionMessage[BUFFER_SIZE];
    char receivedMessage[BUFFER_SIZE];
    int subscriptionCount = 0;

    // 1. Crear el socket UDP
    subscriberSocket = socket(AF_INET, SOCK_DGRAM, 0);
    if (subscriberSocket < 0) {
        perror("Error al crear el socket UDP");
        return 1;
    }
    printf("Socket UDP creado correctamente.\n");

    // 2. Configurar la direccion del broker
    memset(&brokerAddress, 0, sizeof(brokerAddress));
    brokerAddress.sin_family = AF_INET;
    brokerAddress.sin_port = htons(UDP_PORT);

    if (inet_pton(AF_INET, "127.0.0.1", &brokerAddress.sin_addr) != 1) {
        fprintf(stderr, "Direccion IP del broker invalida.\n");
        close(subscriberSocket);
        return 1;
    }

    // 3. Registrar uno o varios partidos desde el mismo socket UDP
    while (1) {
        printf("Ingrese un partido (linea vacia + Enter para terminar): ");
        fflush(stdout);

        if (fgets(selectedMatch, sizeof(selectedMatch), stdin) == NULL) {
            if (ferror(stdin)) {
                perror("Error al leer el partido");
                close(subscriberSocket);
                return 1;
            }
            if (subscriptionCount == 0) {
                fprintf(stderr, "Debe suscribirse al menos a un partido.\n");
                close(subscriberSocket);
                return 1;
            }
            break;
        }

        // Rechazar entradas que no caben en el buffer de lectura
        if (strchr(selectedMatch, '\n') == NULL && !feof(stdin)) {
            int character;
            while ((character = getchar()) != '\n' && character != EOF) { }
            printf("El nombre del partido es demasiado largo.\n");
            continue;
        }

        selectedMatch[strcspn(selectedMatch, "\r\n")] = '\0';
        if (selectedMatch[0] == '\0') {
            if (subscriptionCount == 0) {
                printf("Debe suscribirse al menos a un partido.\n");
                continue;
            }
            break;
        }

        if (strlen(selectedMatch) >= MAX_TOPIC_LENGTH) {
            printf("El partido debe tener maximo %d caracteres.\n", MAX_TOPIC_LENGTH - 1);
            continue;
        }
        if (strchr(selectedMatch, '|') != NULL) {
            printf("El nombre del partido no puede contener '|'.\n");
            continue;
        }

        int messageLength = snprintf(subscriptionMessage, sizeof(subscriptionMessage),
                                     "SUB|%s", selectedMatch);
        if (messageLength < 0 || messageLength >= (int)sizeof(subscriptionMessage)) {
            printf("Mensaje de suscripcion demasiado largo.\n");
            continue;
        }

        ssize_t bytesSent = sendto(subscriberSocket, subscriptionMessage,
                                   (size_t)messageLength, 0,
                                   (struct sockaddr *)&brokerAddress,
                                   sizeof(brokerAddress));
        if (bytesSent != messageLength) {
            if (bytesSent < 0) perror("Error al enviar la suscripcion UDP");
            else fprintf(stderr, "No se envio el datagrama completo.\n");
            close(subscriberSocket);
            return 1;
        }

        subscriptionCount++;
        printf("Suscripcion UDP enviada: %s\n", selectedMatch);
    }

    printf("Esperando publicaciones del broker...\n");

    // 4. Recibir datagramas en el mismo socket usado para suscribirse
    while (1) {
        struct sockaddr_in senderAddress;
        socklen_t senderLength = sizeof(senderAddress);
        ssize_t bytesReceived = recvfrom(subscriberSocket, receivedMessage,
                                         sizeof(receivedMessage) - 1, 0,
                                         (struct sockaddr *)&senderAddress,
                                         &senderLength);
        if (bytesReceived < 0) {
            if (errno == EINTR) continue;
            perror("Error al recibir mensaje UDP");
            break;
        }

        // Solo aceptar noticias procedentes del broker configurado
        if (senderAddress.sin_addr.s_addr != brokerAddress.sin_addr.s_addr ||
            senderAddress.sin_port != brokerAddress.sin_port) {
            printf("Datagrama ignorado: remitente desconocido.\n");
            continue;
        }

        receivedMessage[bytesReceived] = '\0';
        receivedMessage[strcspn(receivedMessage, "\r\n")] = '\0';

        if (strncmp(receivedMessage, "MSG|", 4) != 0) {
            printf("Mensaje recibido con formato invalido.\n");
            continue;
        }

        char *messageSeparator = strchr(receivedMessage + 4, '|');
        if (messageSeparator == NULL || messageSeparator == receivedMessage + 4 ||
            messageSeparator[1] == '\0') {
            printf("Mensaje recibido con formato invalido.\n");
            continue;
        }

        *messageSeparator = '\0';
        char *matchName = receivedMessage + 4;
        char *newsContent = messageSeparator + 1;
        printf("\nPartido: %s\n", matchName);
        printf("Noticia: %s\n", newsContent);
        fflush(stdout);
    }

    close(subscriberSocket);
    return 0;
}
